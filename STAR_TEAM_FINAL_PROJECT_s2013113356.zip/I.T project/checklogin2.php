<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="assignment"; // Database name 
$tbl_name="company"; // Table name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// username and password sent from form 
if (isset($_POST['submit'])){
$COMP_EMAIL=$_POST['COMP_EMAIL']; 
$COMP_PASSWORD=$_POST['COMP_PASSWORD'];
setcookie ("COMP_EMAIL","$COMP_EMAIL",time()+1200);
}
// To protect MySQL injection (more detail about MySQL injection)
$COMP_EMAIL = stripslashes($COMP_EMAIL);
$COMP_PASSOWRD = stripslashes($COMP_PASSWORD);

$COMP_EMAIL = mysql_real_escape_string($COMP_EMAIL);
$COMP_PASSWORD = mysql_real_escape_string($COMP_PASSOWRD);

$sql="SELECT * FROM company WHERE COMP_EMAIL='$COMP_EMAIL' and COMP_PASSWORD='$COMP_PASSWORD'";
$result=mysql_query($sql);

// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count=='1'){

// Register $myusername, $mypassword and redirect to file "login_success.php"
$_SESSION['COMP_EMAIL']= "COMP_EMAILl"; 
$_SESSION['COMP_PASSWORD']= "COMP_PASSWORD";  
 

header("location:company_login_sucess.php");
}

else 
 

echo "<script type='text/javascript'>alert('Wrong Username or Password');
window.location='CompanyLogin.php';
</script>";


?> 