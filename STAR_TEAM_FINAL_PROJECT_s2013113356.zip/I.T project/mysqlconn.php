<?php
	// don't change this
	$hostname="localhost";
	
	// change the username to your student id
	$username="root";
	
	// change the password to your MySQL password
	$password="";
	
	// change the name of the database to your student ID
	$database="assignment";
	
?>