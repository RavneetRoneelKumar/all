<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">
    <link rel="stylesheet" href="css/Search.css">

</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container" align="left"><a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
              <ul class="nav">
                        <li ><a href="index.html">Home</a></li>
                        <li class="active"><a href="SearchNew.php">Job Search</a></li>
                        <li><a href="PostJobLogin.html">Post Job</a></li>
                        <li><a href="aboutUs.html">About US</a></li>
                       
                               
                                <li><a href="resgisterchoice.php">Register</a></li>
                                <li><a href="loginchoice.php">Login</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
    <!-- /header -->

    <section id="slide-show">
                
</section>


<section class="main-info"></section>




<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
   
       <div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
<form class="form-wrapper cf" action="SearchJobLogin.php" method="get">
  	<input type="text" name="keyword" placeholder="Search here..." required>
	  <button type="submit">Search</button>
</form>
		  
</body>
</html>