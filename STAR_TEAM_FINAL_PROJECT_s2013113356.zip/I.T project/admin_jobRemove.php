<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$POST_JOB_CODE=$_POST['POST_JOB_CODE'];
	$POST_COMP_NAME=$_POST['POST_COMP_NAME'];
	$POST_JOB_TITLE=$_POST['POST_JOB_TITLE'];
		
	// build query
	$qry="DELETE FROM POSTJOB WHERE '$POST_JOB_CODE' = POST_JOB_CODE OR '$POST_COMP_NAME' = POST_COMP_NAME OR '$POST_JOB_TITLE' = POST_JOB_TITLE";
	
	
	// execute query
	$removed = mysql_query($qry);
	
	
	// report results
	if($removed != "")
		echo  "Record removed successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be removed<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
	header("location:AdminRemoveJobSucess.php");
?>
