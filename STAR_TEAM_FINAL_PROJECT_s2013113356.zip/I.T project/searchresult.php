<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<?php 
	
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	if(isset($_POST['submit'])){
    $search = $_POST['search'];
}else if(!isset($_POST['submit'])){
   $search = '';
		
}
$searchQuery = "SELECT * FROM `post job` WHERE `POST_JOB_CODE','POST_COMP_NAME,'POST_JOB_DEPARTMENT` LIKE '%$search%'";




//Search the MySQL database with the text value on click
if(isset($_POST['submit'])){
    $searchResults = mysqli_query($dbc, $searchQuery);
    echo '<table border="1px"><tr bgcolor="#313131"><td>POST_JOB_CODE</td><td>POST_COMP_NAME</td><td>POST_JOB_DEPARTMENT</td></tr>';
    while($row1 = mysqli_fetch_array($searchResults)){
        echo '<tr>';
        
        echo '<td>';
        echo $row1['POST_JOB_CODE'];
        echo '</td>';
        
        echo '<td>';
        echo $row1['POST_COMP_NAME'];
        echo '</td>';
        
        echo '<td>';
        echo $row1['POST_JOB_DEPARTMENT'];
        echo '</td>';
        
        echo '</tr>';
    }
    echo '</table>';
}
?>


	
	


<body>

</body>
</html>