<?php
   session_start();
if(!isset($_SESSION['APP_EMAIL'])){
     
   header("location:Applicant_profile.php");
    } 
	
    ?>
   