<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$APP_ID=$_POST['APP_ID'];
	$APP_LNAME=$_POST['APP_LNAME'];
	$APP_FNAME=$_POST['APP_FNAME'];
	$APP_GENDER= $_POST['APP_GENDER'];
	$APP_EMAIL=$_POST['APP_EMAIL'];
	$APP_PASSWORD=$_POST['APP_PASSWORD'];
	$APP_PH_NUMBER=$_POST['APP_PH_NUMBER'];
	$APP_ADDRESS= $_POST['APP_ADDRESS'];
	$APP_DOB= $_POST['APP_DOB'];
	$APP_HOBBIES = $_POST['APP_HOBBIES'];
	$APP_MARITAL_STATUS	=$_POST['APP_MARITAL_STATUS'];
		
	// build query
	$qry="INSERT INTO APPLICANT VALUES("."'$APP_ID','$APP_LNAME','$APP_FNAME','$APP_GENDER','$APP_EMAIL','$APP_PASSWORD','$APP_PH_NUMBER','$APP_ADDRESS','$APP_DOB','$APP_HOBBIES','$APP_MARITAL_STATUS')";
	
	// execute query
	$added = mysql_query($qry);
	
	
	// report results
	if($added != "")
		echo  "Record added successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be added<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
	header("location:ApplicantRegisterSucess.php");
?>
