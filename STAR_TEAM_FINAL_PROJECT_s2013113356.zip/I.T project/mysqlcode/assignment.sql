-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2016 at 05:09 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininstrator`
--

CREATE TABLE `admininstrator` (
  `ADMIN_ID` int(4) NOT NULL,
  `ADMIN_NAME` char(7) NOT NULL,
  `ADMIN_EMAIL` char(15) NOT NULL,
  `ADMIN_PASSWORD` char(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admininstrator`
--

INSERT INTO `admininstrator` (`ADMIN_ID`, `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`) VALUES
(1, 'ADMIN', 'ADMIN@EMAIL.COM', 'ADMIN12');

-- --------------------------------------------------------

--
-- Table structure for table `applicant`
--

CREATE TABLE `applicant` (
  `APP_ID` int(5) NOT NULL,
  `APP_LNAME` char(7) NOT NULL,
  `APP_FNAME` char(7) NOT NULL,
  `APP_GENDER` char(6) NOT NULL,
  `APP_PASSWORD` char(7) NOT NULL,
  `APP_EMAIL` char(15) NOT NULL,
  `APP_PH_NUMBER` int(7) NOT NULL,
  `APP_ADDRESS` varchar(15) NOT NULL,
  `APP_DOB` date NOT NULL,
  `APP_HOBBIES` varchar(20) NOT NULL,
  `APP_MARITAL_STATUS` char(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applicant`
--

INSERT INTO `applicant` (`APP_ID`, `APP_LNAME`, `APP_FNAME`, `APP_GENDER`, `APP_PASSWORD`, `APP_EMAIL`, `APP_PH_NUMBER`, `APP_ADDRESS`, `APP_DOB`, `APP_HOBBIES`, `APP_MARITAL_STATUS`) VALUES
(1, 'Nand', 'Neha', 'F', 'test', '12345', 0, 'test', '0000-00-00', 'singing', 'Single');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `APPLI_ID` int(4) NOT NULL,
  `APP_ID` int(5) NOT NULL,
  `APPLI_LNAME` char(7) NOT NULL,
  `APPLI_FNAME` char(7) NOT NULL,
  `APPLI_PHONE` int(7) NOT NULL,
  `APPLI_MOBILE_NUMBER` int(7) NOT NULL,
  `APPLI_HOBBIES` char(20) NOT NULL,
  `APPLI_MEDICAL_ISSUES` char(20) NOT NULL,
  `APPLI_GENDER` varchar(6) NOT NULL,
  `APPLI_MARITAL_STATUS` char(7) NOT NULL,
  `APPLI_STREET_ADDRESS` varchar(20) NOT NULL,
  `APPLI_EMAIL` char(15) NOT NULL,
  `APPLI_DOB` date NOT NULL,
  `APPLI_PREVIOUS_JOB` char(15) NOT NULL,
  `APPLI_OTHER_DETAILS` char(25) NOT NULL,
  `COMP_NAME` varchar(15) NOT NULL,
  `APPLI_ZIP` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`APPLI_ID`, `APP_ID`, `APPLI_LNAME`, `APPLI_FNAME`, `APPLI_PHONE`, `APPLI_MOBILE_NUMBER`, `APPLI_HOBBIES`, `APPLI_MEDICAL_ISSUES`, `APPLI_GENDER`, `APPLI_MARITAL_STATUS`, `APPLI_STREET_ADDRESS`, `APPLI_EMAIL`, `APPLI_DOB`, `APPLI_PREVIOUS_JOB`, `APPLI_OTHER_DETAILS`, `COMP_NAME`, `APPLI_ZIP`) VALUES
(1, 1, 'TEST', 'TEST', 123, 123, 'TEST', 'TEST', 'F', 'Single', 'test', 'TEST', '1994-02-01', 'TEST', 'TEST', '', 0x50442d50726f78795f56504e2e7a6970),
(2, 1, 'TEST', 'TEST', 123, 123, 'TEST', 'TEST', 'F', 'Married', 'test', 'TEST', '1994-02-01', 'TEST', 'TEST', '', 0x49393530355f585855454d4a355f4d4f44454d2e746172),
(3, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(4, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(5, 1, 'TEST', 'TEST', 123, 123, 'TEST', 'TEST', 'F', 'Single', 'test', 'TEST', '1994-02-01', 'TEST', 'TEST', '', ''),
(6, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(7, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(8, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(9, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(10, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(11, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', '', ''),
(12, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', 'Vodafon', ''),
(13, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', 'Vodafon', ''),
(14, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', 'Vodafon', ''),
(15, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', 'Vodafon', 0x6465766370702d342e392e392e325f73657475702e726172),
(16, 1, '', '', 0, 0, '', '', '', '', '', '', '0000-00-00', '', '', 'FNU', ''),
(17, 1, 'TEST', 'TEST', 123, 123, 'TEST', 'TEST', 'F', 'Single', 'test', 'TEST', '1994-02-01', 'TEST', 'TEST', 'FNU', 0x50442d50726f78795f56504e2e7a6970);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `COMP_ID` int(5) NOT NULL,
  `COMP_NAME` char(7) NOT NULL,
  `COMP_ADDRESS` char(7) NOT NULL,
  `COMP_EMAIL` char(15) NOT NULL,
  `COMP_PASSWORD` char(7) NOT NULL,
  `COMP_PH_NUMBER` int(7) NOT NULL,
  `COMP_ABOUT_US` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`COMP_ID`, `COMP_NAME`, `COMP_ADDRESS`, `COMP_EMAIL`, `COMP_PASSWORD`, `COMP_PH_NUMBER`, `COMP_ABOUT_US`) VALUES
(1, 'FNU', 'Nasinu', 'Test', '12345', 0, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `postjob`
--

CREATE TABLE `postjob` (
  `POST_JOB_CODE` int(5) NOT NULL,
  `POST_COMP_NAME` varchar(15) NOT NULL,
  `POST_JOB_TITLE` varchar(10) NOT NULL,
  `POST_JOB_DESCRIPTION` varchar(15) NOT NULL,
  `POST_JOB_TYPE` varchar(10) NOT NULL,
  `POST_JOB_DEPARTMENT` varchar(15) NOT NULL,
  `POST_JOB_STARTDATE` date NOT NULL,
  `POST_JOB_ENDDATE` date NOT NULL,
  `POST_JOB_CONTACT` varchar(20) NOT NULL,
  `POST_JOB_OTHERDETAILS` varchar(15) NOT NULL,
  `COMP_NAME` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postjob`
--

INSERT INTO `postjob` (`POST_JOB_CODE`, `POST_COMP_NAME`, `POST_JOB_TITLE`, `POST_JOB_DESCRIPTION`, `POST_JOB_TYPE`, `POST_JOB_DEPARTMENT`, `POST_JOB_STARTDATE`, `POST_JOB_ENDDATE`, `POST_JOB_CONTACT`, `POST_JOB_OTHERDETAILS`, `COMP_NAME`) VALUES
(1, 'test', '', '', '', '', '0000-00-00', '0000-00-00', '', '', 'FNU'),
(2, 'TEST', 'test', 'test', 'test', 'test', '1994-08-08', '1994-08-09', '12345', 'test', 'FNU');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininstrator`
--
ALTER TABLE `admininstrator`
  ADD PRIMARY KEY (`ADMIN_ID`);

--
-- Indexes for table `applicant`
--
ALTER TABLE `applicant`
  ADD PRIMARY KEY (`APP_ID`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`APPLI_ID`),
  ADD KEY `APP_ID` (`APP_ID`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`COMP_ID`);

--
-- Indexes for table `postjob`
--
ALTER TABLE `postjob`
  ADD PRIMARY KEY (`POST_JOB_CODE`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
