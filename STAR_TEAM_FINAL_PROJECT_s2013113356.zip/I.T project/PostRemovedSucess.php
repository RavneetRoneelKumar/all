<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Post Job | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

  
    
</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo"  href="index.html"><img src="images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                         <li ><a href="Admin_profile.php">Home</a></li>
                        <li><a href="AdminApplicantAdd.php">Add Applicant Members</a></li>
                        <li><a href="AdminCompanyAdd.php">Add Company Members</a></li>
                        <li class="active"><a href="admin_remove_job_report.php">Remove Post</a></li>
                        <li><a href="admin_remove_applicant_report.php">Remove Applicant Members</a></li>
                        <li><a href="admin_remove_company_report.php">Remove Company Members</a></li>
                       <li><a href="loginchoice.php">LogOut</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
            </div>
        </div>
    </header>
    <!-- /header -->

 

<section class="main-info">
<section id="error" class="container">
 <h1>Congratulation You Have Sucessfully Removed A Post!! </h1>
        <p>What would you like to do now??</p>
        <a class="btn btn-success" href="admin_remove_job_report.php"> Remove Another ?</a> 
             
</section>


<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

       

            <!--Contact Form-->
            <div class="span3">
                <h4>ADDRESS</h4>
                <ul class="unstyled address">
                    <li>
                        <i class="icon-home"></i><strong>Address:</strong> 1234,Fiji<br>
                    Fiji island</li>
                    <li>
                        <i class="icon-envelope"></i>
                        <strong>Email: </strong> support@email.com
                    </li>
                </ul>
            </div>
            <!--End Contact Form-->

</body>
</html>