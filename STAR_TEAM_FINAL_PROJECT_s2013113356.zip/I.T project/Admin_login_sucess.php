<?php
   session_start();
if(!isset($_SESSION['ADMIN_EMAIL'])){
     
	  
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// extract department number
	$ADMIN_ID=$_GET['ADMIN_ID'];	
	
	// retrieve department details
	
	$qry = "Select * from admininstrator where ADMIN_ID = '$ADMIN_ID'";
	
	

	 
	 
   header("location:Admin_profile.php");
    } 
	
    ?>
   