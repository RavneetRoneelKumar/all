<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="assignment"; // Database name 
$tbl_name="applicant"; // Table name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// username and password sent from form 
if (isset($_POST['submit'])){
$APP_EMAIL=$_POST['APP_EMAIL']; 
$APP_PASSWORD=$_POST['APP_PASSWORD']; 
setcookie ("APP_EMAIL","$APP_EMAIL",time()+1200);
}
// To protect MySQL injection (more detail about MySQL injection)
$APP_EMAIL = stripslashes($APP_EMAIL);
$APP_PASSWORD = stripslashes($APP_PASSWORD);

$APP_EMAIL = mysql_real_escape_string($APP_EMAIL);
$APP_PASSWORD = mysql_real_escape_string($APP_PASSWORD);

$sql="SELECT * FROM applicant WHERE APP_EMAIL='$APP_EMAIL' and APP_PASSWORD='$APP_PASSWORD'";
$result=mysql_query($sql);

// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count=='1'){

// Register $myusername, $mypassword and redirect to file "login_success.php"
$_SESSION['APP_EMAIL']= "APP_EMAIL"; 
$_SESSION['APP_PASSOWRD']= "APP_PASSWORD"; 

 

header("location:applicant_login_sucess.php");
}

else 
 

echo "<script type='text/javascript'>alert('Wrong Username or Password');
window.location='ApplicantLogin.php';
</script>";


?> 