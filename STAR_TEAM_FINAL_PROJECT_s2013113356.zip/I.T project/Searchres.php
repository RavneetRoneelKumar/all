 <?php 
	
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	$POST_JOB_CODE= $_POST['POST_JOB_CODE'];
	$COMP_NAME= $_POST['COMP_NAME'];
	$POST_COMP_NAME= $_POST['POST_COMP_NAME'];
	$POST_JOB_TITLE= $_POST['POST_JOB_TITLE'];
	$POST_DESCRIPTION= $_POST['POST_JOB_DESCRIPTION'];
	$QUERY=mysql_query("SELECT * FROM postjob WHERE POST_JOB_CODE LIKE '$POST_JOB_CODE%' OR COMP_NAME LIKE '$COMP_NAME%' OR POST_JOB_TITLE LIKE '$POST_JOB_TITLE%' OR POST_JOB_DESCRIPTION LIKE '$POST_JOB_DESCRIPTION%'");
	while($run=mysql_fetch_array($QUERY)){
	echo "<tr><td>";
		echo "<a href=applyJob.php?POST_JOB_CODE=" . $line['POST_JOB_CODE'] .
			">" . $line['POST_JOB_CODE'] . "</a></td>";
		echo "<td>" .$line['COMP_NAME']. "</td><td> "   .$line['POST_COMP_NAME'] . "<td>" .$line['POST_JOB_TITLE'] . "</td>";
		echo "<td>".$line['POST_JOB_DESCRIPTION']."</td> </tr>";
	}
	

	
	
?>
