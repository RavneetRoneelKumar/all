<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Admin Remove Job| ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head>

<body>

     <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo"  href="index.html"><img src="images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li ><a href="Admin_profile.php">Home</a></li>
                        <li><a href="AdminApplicantAdd.php">Add Applicant Members</a></li>
                        <li><a href="AdminCompanyAdd.php">Add Company Members</a></li>
                        <li class="active"><a href="admin_remove_job_report.php">Remove Post</a></li>
                        <li><a href="admin_remove_applicant_report.php">Remove Applicant Members</a></li>
                        <li><a href="admin_remove_company_report.php">Remove Company Members</a></li>
                       <li><a href="loginchoice.php">LogOut</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
            </div>
        </div>
    </header>
            <section class="main-info">
            <form method="post" action="postRemove.php" name="applicant">
  
 <center>
<table width="71%" height="97" border="1">
  <tbody>
    <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" width="70%">
	<td height="36" colspan="5" style="text-align: center; background-color: #000; width: 100%;">
      <center style="margin-left:10px; width: 1000px;">
      <big><big> Post Job Report</big></big>
      </center>
      </td>
    </tr>
    <tr>
	<td width="11%"><b>JOB CODE</b></td>

	<td width="17%"><b>COMPANY NAME</b></td>

	<td width="22%"><b>COMPANY USER</b></td>

	<td width="21%"><b>JOB TITLE</b></td>
    
    <td width="29%"><b>JOB DESCRIPTION</b></td>
    
    
	
    </tr>
<?php // include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// check whether you have connected to database or not
	if (!$dbconn) 
	{
		die('Could not connect: ' . mysql_error());
	}
	
	// build query
	$qry = "Select * from postjob";
	
	//execute query
	$job = mysql_query($qry) or die('Query failed: ' . mysql_error());

	// write a loop to print out the results.
	while ($line = mysql_fetch_array($job, MYSQL_ASSOC)) 
	{ 
		echo "<tr><td>";
		echo "<a href=PostJobFormREMOVE.php?POST_JOB_CODE=" . $line['POST_JOB_CODE'] .
			">" . $line['POST_JOB_CODE'] . "</a></td>";
		echo "<td>" .$line['COMP_NAME']. "</td><td> "   .$line['POST_COMP_NAME'] . "<td>" .$line['POST_JOB_TITLE'] . "</td>";
		echo "<td>".$line['POST_JOB_DESCRIPTION']."</td> </tr>";
	}

	// close connection
	mysql_close($dbconn);
?>
</tbody>
 
</table>
</selection>
        </div>
    </header>
    <!-- /header -->

   
</body>
</html>