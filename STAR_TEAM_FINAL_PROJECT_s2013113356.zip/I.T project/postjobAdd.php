<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$POST_JOB_CODE=$_POST['POST_JOB_CODE'];
	$POST_COMP_NAME=$_POST['POST_COMP_NAME'];
	$POST_JOB_TITLE= $_POST['POST_JOB_TITLE'];
	$POST_JOB_DESCRIPTION=$_POST['POST_JOB_DESCRIPTION'];
	$POST_JOB_TYPE=$_POST['POST_JOB_TYPE'];
	$POST_JOB_DEPARTMENT=$_POST['POST_JOB_DEPARTMENT'];
	$POST_JOB_STARTDATE= $_POST['POST_JOB_STARTDATE'];
	$POST_JOB_ENDDATE= $_POST['POST_JOB_ENDDATE'];
	$POST_JOB_CONTACT = $_POST['POST_JOB_CONTACT'];
	$POST_JOB_OTHERDETAILS	=$_POST['POST_JOB_OTHERDETAILS'];
	$COMP_NAME=$_POST['COMP_NAME'];

	// build query
	$qry="INSERT INTO postjob VALUES("."'$POST_JOB_CODE','$POST_COMP_NAME','$POST_JOB_TITLE','$POST_JOB_DESCRIPTION','$POST_JOB_TYPE','$POST_JOB_DEPARTMENT','$POST_JOB_STARTDATE','$POST_JOB_ENDDATE','$POST_JOB_CONTACT','$POST_JOB_OTHERDETAILS','$COMP_NAME')";
	
	// execute query
	$added = mysql_query($qry);
	
	
	// report results
	if($added != "")
		echo  "Record added successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be added<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
	header("location:PostJobSucess.php");
?>
