<!DOCTYPE html>
 <html class="no-js"> 
<head>
 <?php 
	
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// get the next employee number
	$nextemp = mysql_query("select max(COMP_ID) as ncomp from company") 
				or die('Query failed: ' . mysql_error());
		
	$line = mysql_fetch_array($nextemp, MYSQL_ASSOC);
	
	$nextCompNum = $line['ncomp'] + 1;
	
	
	
?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

   
</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li ><a href="index.html">Home</a></li>
                        <li><a href="SearchNew.php">Job Search</a></li>
                        <li><a href="PostJobLogin.html">Post Job</a></li>
                        <li><a href="aboutUs.html">About US</a></li>
                       
                               
                                <li class="active"><a href="resgisterchoice.php">Register</a></li>
                                <li><a href="loginchoice.php">Login</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>
<!--/Slider-->

<section class="main-info"></section>

<!--Services--><!--/Services-->


<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
    <form method="post" action="compAdd.php" name="company">
  
  <table style="background-color: rgb(245, 245, 245); width: 75%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="2" cellspacing="2">

<tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#333;"><big><big>COMPANY REGISTRATION FORM</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Company ID: </td>
      <td style="width: 400px;"><input name="COMP_ID" value='<?php echo $nextCompNum; ?>'></td>
    </tr>
    <tr>
      <td height="32" style="text-align: left; width: 30%;"> Company Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="COMP_NAME"></td>
    </tr>
    	<td height="34" style="text-align: left; width: 30%;"> Address: </td>
      <td style="width: 400px;"><input name="COMP_ADDRESS" maxlength="20" size="20"></td>
     </tr>
      <td height="34" style="text-align: left; width: 30%;">Email: </td>
      <td style="width: 400px;"><input name="COMP_EMAIL" maxlength="20" size="20"></td>
    </tr>
      <td height="33" style="text-align: left; width: 30%;">Password: </td>
      <td style="width: 400px;"><input name="COMP_PASSWORD" maxlength="15" size="15"></td>
    </tr>
      <td height="32" style="text-align: left; width: 30%;">Phone No: </td>
      <td style="width: 400px;"><input  name="COMP_PH_NUMBER" id="p" maxlength="7" size="7"></td>
    </tr>
      <td height="33" style="text-align: left; width: 30%;">Company Details: </td>
      <td style="width: 400px;"><input name="COMP_ABOUT_US" maxlength="15" size="15"></td>
    </tr>
    <tr align="left">
      <td colspan="2" style="text-align:center; width: 588px;"><input name="Submit" value="Register" type="submit"><input name="Reset" value="Clear" type="reset"></td>
    </tr>
  </tbody>
</table>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>

</body>
</html>