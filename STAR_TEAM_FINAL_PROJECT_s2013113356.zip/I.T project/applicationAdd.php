<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$APPLI_ID=$_POST['APPLI_ID'];
	$APP_ID=$_POST['APP_ID'];
	$APPLI_LNAME=$_POST['APPLI_LNAME'];
	$APPLI_FNAME= $_POST['APPLI_FNAME'];
	$APPLI_PHONE=$_POST['APPLI_PHONE'];
	$APPLI_MOBILE_NUMBER=$_POST['APPLI_MOBILE_NUMBER'];
	$APPLI_HOBBIES=$_POST['APPLI_HOBBIES'];
	$APPLI_MEDICAL_ISSUES= $_POST['APPLI_MEDICAL_ISSUES'];
	$APPLI_GENDER= $_POST['APPLI_GENDER'];
	$APPLI_MARITAL_STATUS = $_POST['APPLI_MARITAL_STATUS'];
	$APPLI_STREET_ADDRESS	=$_POST['APPLI_STREET_ADDRESS'];
	$APPLI_EMAIL=$_POST['APPLI_EMAIL'];
	$APPLI_DOB=$_POST['APPLI_DOB'];
	$APPLI_PREVIOUS_JOB=$_POST['APPLI_PREVIOUS_JOB'];
	$APPLI_OTHER_DETAILS=$_POST['APPLI_OTHER_DETAILS'];
	$COMP_NAME=$_POST['COMP_NAME'];
	$APPLI_ZIP=$_POST['APPLI_ZIP'];

	// build query
	$qry="INSERT INTO APPLICATION VALUES("."'$APPLI_ID','$APP_ID','$APPLI_LNAME','$APPLI_FNAME','$APPLI_PHONE','$APPLI_MOBILE_NUMBER','$APPLI_HOBBIES','$APPLI_MEDICAL_ISSUES','$APPLI_GENDER','$APPLI_MARITAL_STATUS','$APPLI_STREET_ADDRESS','$APPLI_EMAIL','$APPLI_DOB','$APPLI_PREVIOUS_JOB','$APPLI_OTHER_DETAILS','$COMP_NAME','$APPLI_ZIP')";
	
	// execute query
	$added = mysql_query($qry);
	
	
	// report results
	if($added != "")
		echo  "Record added successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be added<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
	header("location:ApplicationAddSucess.php");
?>
