<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$APP_ID=$_POST['APP_ID'];
	$APP_LNAME=$_POST['APP_LNAME'];
	$APP_FNAME=$_POST['APP_FNAME'];
	$APP_EMAIL=$_POST['APP_EMAIL'];
		
	// build query
	$qry="DELETE FROM APPLICANT WHERE '$APP_ID' = APP_ID OR '$APP_LNAME' = APP_LNAME OR '$APP_FNAME' = APP_FNAME OR '$APP_EMAIL' = APP_EMAIL" ;
	
	// execute query
	$removed = mysql_query($qry);
	
	
	// report results
	if($removed != "")
		echo  "Record removed successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be removed<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
?>
