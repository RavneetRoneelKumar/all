<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	$username= $_REQUEST['id'];
	
	
	$get = mysql_query("SELECT * FROM  profile WHERE id = '$id'");
	$get2 = mysql_fetch_assoc($get);
	$username=$get2('username');
?>

<html>
<body>

HELLO <b> <?php echo $ADMIN_ID;  ?></b>
</body>
</html>