<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Admin Add Members | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo"  href="index.html"><img src="images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li class="active" ><a href="index.html">Home</a></li>
                        <li><a href="Admin_Add_Applicant_New.php">Add Applicant Members</a></li>
                        <li><a href="Admin_Add_Company_New.php">Add Company Members</a></li>
                        <li><a href="Admin_Remove_Post.php">Remove Post</a></li>
                        <li><a href="Admin_Remove_Applicant.php">Remove Applicant Members</a></li>
                        <li><a href="Admin_Remove_Company.php">Remove Company Members</a></li>
                       <li><a href="loginchoice.php">LogOut</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
            </div>
        </div>
    </header>
            <section id="bottom" class="main">
            <form method="post" action="Admin_appAdd.php" name="applicant">
  
  <table style="background-color: rgb(245, 245, 245); width: 75%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="2" cellspacing="2">

<tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#333;"><big><big>APPLICANT ADD FORM</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Applicant ID: </td>
      <td style="width: 400px;"><input name="APP_ID" value='<?php echo $nextAppId; ?>'></td>
    </tr>
    <tr>
      <td height="32" style="text-align: left; width: 30%;"> Last Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="APP_LNAME"></td>
    </tr>
    <td height="34" style="text-align: left; width: 30%;">First Name: </td>
      <td style="width: 400px;"><input name="APP_FNAME" maxlength="15" size="15"></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">Gender: </td>
      <td style="width: 400px;"><input type="radio" value="F" name="APP_GENDER"> Female
      <input type="radio" value="M" name="APP_GENDER"> Male</td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Email: </td>
      <td style="width: 400px;"><input name="APP_EMAIL" maxlength="20" size="20"></td>
    </tr>
      <td height="33" style="text-align: left; width: 30%;">Password: </td>
      <td style="width: 400px;"><input name="APP_PASSWORD" maxlength="15" size="15"></td>
    </tr>
      <td height="32" style="text-align: left; width: 30%;">Phone No: </td>
      <td style="width: 400px;"><input  name="APP_PH_NUMBER" id="p"></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Address: </td>
      <td style="width: 400px;"><input name="APP_ADDRESS" maxlength="20" size="20"></td>
     </tr>
      <td height="33" style="text-align: left; width: 30%;">Date of Birth: (YYYY/MM/DD) </td>
      <td style="width: 400px;"><input name="APP_DOB" maxlength="15" size="15"></td>
    </tr>
      <td height="33" style="text-align: left; width: 30%;">Hobbies: </td>
      <td style="width: 400px;"><input name="APP_HOBBIES" maxlength="15" size="15"></td>
    </tr>
      <td height="30" style="text-align: left; width: 30%;">Marital Status: </td>
      <td style="width: 400px;"><input type="radio" value="Single" name="APP_MARITAL_STATUS"> Single
      <input type="radio" value="Married" name="APP_MARITAL_STATUS"> Married
      <input type="radio" value="Divorced" name="APP_MARITAL_STATUS"> Divorced</td>
    </tr>
    <tr align="left">
      <td colspan="2" style="text-align:center; width: 588px;"><input name="Submit" value="Add Member" type="submit"><input name="Reset" value="Clear" type="reset"></td>
    </tr>
  </tbody>
</table>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>
</selection>
        </div>
    </header>
    <!-- /header -->

   
</body>
</html>