<?php
   session_start();
if(!isset($_SESSION['COMP_EMAIL'])){
     
   header("location:Company_profile.php");
    } 
	
    ?>
   