<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="assignment"; // Database name 
$tbl_name="admininstrator"; // Table name 

// Connect to server and select databse.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");

// username and password sent from form 
if (isset($_POST['submit'])){
$ADMIN_EMAIL=$_POST['ADMIN_EMAIL']; 
$ADMIN_PASSWORD=$_POST['ADMIN_PASSWORD']; 
setcookie ("ADMIN_EMAIL","$ADMIN_EMAIL",time()+1200);
}
// To protect MySQL injection (more detail about MySQL injection)
$ADMIN_EMAIL = stripslashes($ADMIN_EMAIL);
$ADMIN_PASSWORD = stripslashes($ADMIN_PASSWORD);

$ADMIN_EMAIL = mysql_real_escape_string($ADMIN_EMAIL);
$ADMIN_PASSWORD = mysql_real_escape_string($ADMIN_PASSWORD);

$sql="SELECT * FROM admininstrator WHERE ADMIN_EMAIL='$ADMIN_EMAIL' and ADMIN_PASSWORD='$ADMIN_PASSWORD'";

// build query
	$qry = "Select * from admininstrator";
	
	//execute query
	$applicant = mysql_query($qry) or die('Query failed: ' . mysql_error());

	

$result=mysql_query($sql);


	
	
// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count=='1'){

// Register $myusername, $mypassword and redirect to file "login_success.php"
$_SESSION['ADMIN_EMAIL']= "ADMIN_EMAIL"; 
$_SESSION['ADMIN_PASSWORD']= "ADMIN_PASSWORD"; 

 

header("location:Admin_login_sucess.php");
}

else 
 

echo "<script type='text/javascript'>alert('Wrong Username or Password');
window.location='AdminLogin.php';
</script>";


?> 