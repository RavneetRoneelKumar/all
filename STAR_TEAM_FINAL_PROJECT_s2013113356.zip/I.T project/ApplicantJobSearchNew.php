<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">
    <link rel="stylesheet" href="css/Search.css">

</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container" align="left"><a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
              <ul class="nav">
                         <li  ><a href="Applicant_profile.php">Home</a></li>
                        <li><a href="Applicant_profileview.php">Profile</a></li>
                        <li class="active"><a href="ApplicantJobSearchNew.php">Job Search</a></li>
                        <li><a href="ApplicantionForm.php">Apply Job</a></li>
                        
                       
                               
              
                                <li><a href="loginchoice.php">LogOut</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
    <!-- /header -->

    <section id="slide-show">
                
</section>


<section class="main-info"></section>




<!--Bottom-->
<section class="main-info">
    <!--Container-->
   
       <div style="margin-right: 80px;"></div>


            <form method="post" action="applyJob.php" name="applicant">
  
 <center>
<table width="71%" height="97" border="1">
  <tbody>
    <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" width="70%">
	<td height="36" colspan="5" style="text-align: center; background-color: #000; width: 100%;">
      <center style="margin-left:10px; width: 1000px;">
      <big><big> Available Jobs</big></big>
      </center>
      </td>
    </tr>
    <tr>
	<td width="11%"><b>JOB CODE</b></td>

	<td width="17%"><b>COMPANY NAME</b></td>

	<td width="22%"><b>COMPANY USER</b></td>

	<td width="21%"><b>JOB TITLE</b></td>
    
    <td width="29%"><b>JOB DESCRIPTION</b></td>
    
    
	
    </tr>
<?php // include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// check whether you have connected to database or not
	if (!$dbconn) 
	{
		die('Could not connect: ' . mysql_error());
	}
	
	// build query
	$qry = "Select * from postjob";
	
	//execute query
	$job = mysql_query($qry) or die('Query failed: ' . mysql_error());

	// write a loop to print out the results.
	while ($line = mysql_fetch_array($job, MYSQL_ASSOC)) 
	{ 
		echo "<tr><td>";
		echo "<a href=applyJob.php?POST_JOB_CODE=" . $line['POST_JOB_CODE'] .
			">" . $line['POST_JOB_CODE'] . "</a></td>";
		echo "<td>" .$line['COMP_NAME']. "</td><td> "   .$line['POST_COMP_NAME'] . "<td>" .$line['POST_JOB_TITLE'] . "</td>";
		echo "<td>".$line['POST_JOB_DESCRIPTION']."</td> </tr>";
	}

	// close connection
	mysql_close($dbconn);
?>
</tbody>
 
</table>
</selection>	  
</body>
</html>