<?php
	//include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or die('Could not connect: ' .
	mysql_error());

	// check whether you have connected to database or not
	
	if (!$dbconn)
	{
	die('Could not connect: ' . mysql_error());
	}
	// set the active database as your database. 	
	 mysql_select_db($database, $dbconn);
	
	// extract form values
	$COMP_ID=$_POST['COMP_ID'];
	$COMP_NAME=$_POST['COMP_NAME'];
	$COMP_ADDRESS=$_POST['COMP_ADDRESS'];
	$COMP_EMAIL=$_POST['COMP_EMAIL'];
	$COMP_PASSWORD=$_POST['COMP_PASSWORD'];
	$COMP_PH_NUMBER=$_POST['COMP_PH_NUMBER'];
	$COMP_ABOUT_US= $_POST['COMP_ABOUT_US'];
		
	// build query
	$qry="INSERT INTO company VALUES("."'$COMP_ID','$COMP_NAME','$COMP_ADDRESS','$COMP_EMAIL','$COMP_PASSWORD','$COMP_PH_NUMBER','$COMP_ABOUT_US')";
	
	// execute query
	$added = mysql_query($qry);
	
	
	// report results
	if($added != "")
		echo  "Record added successfully!!!." . "<br>";
	else
	{
		echo "ERROR: Record could not be added<br>" . 
			 mysql_error();
	}
	//close database connection
	mysql_close($dbconn);
	header("location:RegisterSucess.php");
?>
