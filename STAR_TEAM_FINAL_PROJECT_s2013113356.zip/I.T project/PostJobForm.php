<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

   
    
    
    
    
    
     <?php 
	
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// get the next company number
	$nextAppId = mysql_query("select max(POST_JOB_CODE) as napp from postjob") 
				or die('Query failed: ' . mysql_error());
		
	$line = mysql_fetch_array($nextAppId, MYSQL_ASSOC);
	
	$nextAppId = $line['napp'] + 1;
	
?>





</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                       <li ><a href="Company_profile.php">Home</a></li>
                        <li><a href="Company_profileview.php">Profile</a></li>
                        <li class="active" ><a href="PostJobForm.php">POST job</a></li>
                       
                       <li ><a href="Applicantcv.php">APPLICANT CV</a></li>
                                <li><a href="loginchoice.php">Logout</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div>
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>







<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
     <form method="post" action="postjobAdd.php" name="company">
  
  <table style="background-color: rgb(245, 245, 245); width: 75%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="2">

<tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#333;"><big><big>POST JOB FORM</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Job Code: </td>
      <td style="width: 400px;"><input name="POST_JOB_CODE" readonly="readonly" value='<?php echo $nextAppId; ?>'></td>
    </tr>
     
    <tr>
      <td height="32" style="text-align: left; width: 30%;">  Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="POST_COMP_NAME"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Title: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="POST_JOB_TITLE"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Description: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="POST_JOB_DESCRIPTION"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Title: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="POST_JOB_TYPE"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;">Job Department: </td>
      <td style="width: 588px; font-family: Verdana;"><input maxlength="15" size="15" name="POST_JOB_DEPARTMENT"></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Start Date : </td>
      <td style="width: 400px;"><input name="POST_JOB_STARTDATE" maxlength="15" size="15"></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">End Date: </td>
      <td style="width: 400px;"><input  name="POST_JOB_ENDDATE"> 
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Job Contact: </td>
      <td style="width: 400px;"><input  name="POST_JOB_CONTACT"> 
    </tr>
      <td height="32" style="text-align: left; width: 30%;">Other Details: </td>
      <td style="width: 400px;"><input  name="POST_JOB_OTHERDETAILS" id="p"></td>
    </tr>
    <tr>
      <td height="32" style="text-align: left; width: 30%;">Company Name: </td>
      
      <td style="width: 588px; font-family: Verdana;">
 <select size="1" name="COMP_NAME">
<?php 
	
	$ID = mysql_query("select * from company") or die('Query failed: ' . mysql_error());
		
	while ($line = mysql_fetch_array($ID, MYSQL_ASSOC)) 
	{ 
		echo "<option value='" . $line['COMP_NAME'] . "'>"; 
		echo $line['COMP_NAME'] . "</option>"; 
	} 
?>
        </select> 
        <p>*NOTE: PLEASE FILL OUT THE FORM CAREFULLY AS YOU CANNOT UPDATE THE FORM AFTER SUBMISION </p>
      </td>
      
    </tr>  
         

    </td>
    </tr>
    </tbody>
    </tbody>
    
    <tr align="left">
      <td colspan="2" style="text-align:center; width: 588px;"><input name="Submit" value="Post" type="submit"><input name="Reset" value="Clear" type="reset"></td>
    </tr>
    
   
  </tbody>
  </table>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>
<?php 
	// close connection to database 
	mysql_close($dbconn);
?>
</body>
</html>