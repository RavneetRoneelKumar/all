<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

   
    
    
    
    
    
    <?php 
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// extract department number
	$POST_JOB_CODE=$_GET['POST_JOB_CODE'];	
	
	// retrieve department details
	
	$qry = "Select * from postjob where POST_JOB_CODE = '$POST_JOB_CODE'";
	
	$rs = mysql_query($qry) or die('Query failed: ' . mysql_error());
	
	if(!$rs or mysql_num_rows($rs)> 1)
	{
		echo "Cannot find applicant record";
		mysql_close($dbconn);
		die();
	}
	$record = mysql_fetch_array($rs, MYSQL_ASSOC); 
?>





</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li  ><a href="Applicant_profile.php">Home</a></li>
                        <li><a href="Applicant_profileview.php">Profile</a></li>
                        <li class="active"><a href="ApplicantJobSearchNew.php">Job Search</a></li>
                        <li><a href="ApplicantionForm.php">Apply Job</a></li>
                        
                       
                               
              
                                <li><a href="loginchoice.php">LogOut</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div>
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>







<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
     <form method="post" action="ApplicantionForm.php" name="applicant">
  
  <table style="background-color: rgb(245, 245, 245); width: 75%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="2">

<tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#333;"><big><big> JOB DETAILS</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Job Code: </td>
      <td style="width: 400px;"><input name="POST_JOB_ID" readonly="readonly" value='<?php echo $record['POST_JOB_CODE']; ?>''></td>
    </tr>
     
    <tr>
      <td height="32" style="text-align: left; width: 30%;">  Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="POST_COMP_NAME" readonly="readonly" value='<?php echo $record['POST_COMP_NAME']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Title: </td>
      <td style="width: 588px; font-family: Verdana;">
      <input name="POST_JOB_TITLE" readonly="readonly" value='<?php echo $record['POST_JOB_TITLE']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Description: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="POST_JOB_DESCRIPTION" readonly="readonly" value='<?php echo $record['POST_JOB_DESCRIPTION']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Job Title: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="POST_JOB_TITLE" readonly="readonly" value='<?php echo $record['POST_JOB_TITLE']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;">Job Department: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="POST_JOB_DEPARTMENT" readonly="readonly" value='<?php echo $record['POST_JOB_DEPARTMENT']; ?>'"></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Start Date : </td>
      <td style="width: 400px;"><input name="POST_JOB_STARTDATE" readonly="readonly" value='<?php echo $record['POST_JOB_STARTDATE']; ?>'"></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">End Date: </td>
      <td style="width: 400px;"><input name="APP_ID" readonly="readonly" value='<?php echo $record['POST_JOB_ENDDATE']; ?>'"> 
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Job Contact: </td>
      <td style="width: 400px;"><input name="POST_JOB_ENDDATE" readonly="readonly" value='<?php echo $record['POST_JOB_ENDDATE']; ?>'"> 
    </tr>
      <td height="32" style="text-align: left; width: 30%;">Other Details: </td>
      <td style="width: 400px;"><input name="POST_JOB_OTHERDETAILS" readonly="readonly" value='<?php echo $record['POST_JOB_OTHERDETAILS']; ?>'"></td>
      
    </tr>
      <tr>
      <td height="32" style="text-align: left; width: 30%;">Company ID: </td>
      <td style="width: 588px; font-family: Verdana;">
<input name="COMP_NAME" readonly="readonly" value='<?php echo $record['COMP_NAME']; ?>''>
      </td>
    </tr>
         

    </td>
    </tr>
    </tbody>
    </tbody>
    
    <tr align="left">
      <td colspan="2" style="text-align:center; width: 588px;"><input name="Submit" value="Apply Now" type="submit"></td>
    </tr>
    
   
  </tbody>
  </table>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>

</body>
</html>