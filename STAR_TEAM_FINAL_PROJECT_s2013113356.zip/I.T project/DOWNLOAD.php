<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php
 

	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// extract department number
	$APPLI_ZIP=$_GET['APPLI_ZIP'];	
	
	// retrieve department details
	
	$qry = "Select * from application where APPLI_ZIP = '$APPLI_ZIP'";
	
	$rs = mysql_query($qry) or die('Query failed: ' . mysql_error());
	
	if(!$rs or mysql_num_rows($rs)> 1)
	{
		echo "Cannot find applicant record";
		mysql_close($dbconn);
		die();
	}
	$record = mysql_fetch_array($rs, MYSQL_ASSOC); 
?> 
<body>
<a href=""/>DOWNLOAD
</body>
</html>