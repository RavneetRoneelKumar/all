<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

   
    
    
    
    
    
    <?php 
	// include the file that defines (contains) the username and password
	require_once("mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	// extract department number
	$APPLI_ID=$_GET['APPLI_ID'];	
	
	// retrieve department details
	
	$qry = "Select * from application where APPLI_ID = '$APPLI_ID'";
	
	$rs = mysql_query($qry) or die('Query failed: ' . mysql_error());
	
	if(!$rs or mysql_num_rows($rs)> 1)
	{
		echo "Cannot find applicant record";
		mysql_close($dbconn);
		die();
	}
	$record = mysql_fetch_array($rs, MYSQL_ASSOC); 
?>





</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li ><a href="Company_profile.php">Home</a></li>
                        <li><a href="">Profile</a></li>
                        <li ><a href="PostJobForm.php">POST job</a></li>
                       
                       <li class="active"><a href="Applicantcv.php">APPLICANT CV</a></li>
                                <li><a href="loginchoice.php">Logout</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div>
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>







<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
     <form method="post" action="DOWNLOAD.php" name="applicant">
  
  <table style="background-color: rgb(245, 245, 245); width: 75%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="0" cellspacing="2">

<tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#333;"><big><big>APPLICANTION FORM</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Applicantion ID: </td>
      <td style="width: 400px;"><input name="APPLI_ID" readonly="readonly" value='<?php echo $record['APPLI_ID']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;">Applicant ID: </td>
      <td style="width: 588px; font-family: Verdana;">
        <input name="APP_ID" readonly="readonly" value='<?php echo $record['APP_ID']; ?>'"></td>
        
      
      
      </td>
    </tr>
    <tr>
      <td height="32" style="text-align: left; width: 30%;"> Last Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="APPLI_LNAME" readonly="readonly" value='<?php echo $record['APPLI_LNAME']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> First Name: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="APPLI_FNAME" readonly="readonly" value='<?php echo $record['APPLI_FNAME']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Phone: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="APPLI_PHONE" readonly="readonly" value='<?php echo $record['APPLI_PHONE']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;"> Mobile: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="APPLI_MOBILE_NUMBER" readonly="readonly" value='<?php echo $record['APPLI_MOBILE_NUMBER']; ?>'"></td>
    </tr>
     <tr>
      <td height="32" style="text-align: left; width: 30%;">Hobbies: </td>
      <td style="width: 588px; font-family: Verdana;"><input name="APPLI_HOBBIES" readonly="readonly" value='<?php echo $record['APPLI_HOBBIES']; ?>'"></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Medical Issues: </td>
      <td style="width: 400px;"><input name="APPLI_MEDICAL_ISSUES" readonly="readonly" value='<?php echo $record['APPLI_MEDICAL_ISSUES']; ?>'"></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">Gender: </td>
      <td style="width: 400px;"><input name="APPLI_GENDER" readonly="readonly" value='<?php echo $record['APPLI_GENDER']; ?>'">
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Marital Status: </td>
      <td style="width: 400px;"><input name="APPLI_MARITAL_STATUS" readonly="readonly" value='<?php echo $record['APPLI_MARITAL_STATUS']; ?>'">
    </tr>
      <td height="32" style="text-align: left; width: 30%;">Street Address: </td>
      <td style="width: 400px;"><input name="APPLI_STREET_ADDRESS" readonly="readonly" value='<?php echo $record['APPLI_STREET_ADDRESS']; ?>'"></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;">Email: </td>
      <td style="width: 400px;"><input name="APPLI_EMAIL" readonly="readonly" value='<?php echo $record['APPLI_EMAIL']; ?>'"></td>
     </tr>
      <td height="33" style="text-align: left; width: 30%;">Date of Birth: (YYYY/MM/DD) </td>
      <td style="width: 400px;"><input name="APPLI_DOB" readonly="readonly" value='<?php echo $record['APPLI_DOB']; ?>'"></td>
    </tr>
        <td height="33" style="text-align: left; width: 30%;">Previous Job: </td>
      <td style="width: 400px;"><input name="APPLI_PREVIOUS_JOB" readonly="readonly" value='<?php echo $record['APPLI_PREVIOUS_JOB']; ?>'"></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">Other Detals: </td>
      <td style="width: 400px;"><input name="APPLI_OTHER_DETAILS" readonly="readonly" value='<?php echo $record['APPLI_OTHER_DETAILS']; ?>'"></td>
    </tr>
<tr>
      <td height="32" style="text-align: left; width: 30%;">Company Name:  </td>
      <td style="width: 588px; font-family: Verdana;">  <input name="COMP_NAME" readonly="readonly" value='<?php echo $record['COMP_NAME']; ?>'">
      </td>
</tr>
    <tr>
    <td>
    <form method="post" enctype="multipart/form-data">
        <br/>
        <P> PLEASE UPLOAD YOUR ZIP FILE( ZIP FILE REQUIRED)</P>
  <input readonly="readonly" name="APPLI_ZIP"  value='<?php  echo $record['APPLI_ZIP'];
   ?> ' ">
  
 
         
</form>

      
      </td>
    </tr>
    </td>
    </tr>
    </tbody>
    </tbody>
    
    <tr align="left">
      <td colspan="2" style="text-align:center; width: 588px;">&nbsp;</td>
    </tr>
    
   
  </tbody>
  </table>
<div style="margin-right: 80px;"></div>

<div class="clfix"> </div>
		   </form>

</body>
</html>