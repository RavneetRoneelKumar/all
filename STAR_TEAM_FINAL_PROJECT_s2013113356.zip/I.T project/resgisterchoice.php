<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

   
</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li ><a href="index.html">Home</a></li>
                        <li><a href="SearchNew.php">Job Search</a></li>
                        <li><a href="PostJobLogin.html">Post Job</a></li>
                        <li><a href="aboutUs.html">About US</a></li>
                       
                               
                                <li class="active"><a href="">Register</a></li>
                                <li ><a href="loginchoice.php">Login</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>
<!--/Slider-->

<section class="main-info"></section>

<!--Services--><!--/Services-->


<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
    <div class="container">

        <!--row-fluids-->
        <div class="row-fluid">
			<h1 align="center">REGISTRATION</h1>
            <!--Contact Form-->
            <div class="span3">
                <div class="service-grids">
                  <div class="col-md-3">
                    <div class="service-grid text-center">
                      <h3>&nbsp;</h3>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="service-grid text-center">
                     
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="service-grid text-center"></div>
                  </div>
                  <div class="clearfix"> </div>
                </div>
                <h4>&nbsp;</h4>
            </div>
            
            <div class="span3">
                <div class="service-grids">
                  <div class="col-md-3">
                    <div class="service-grid text-center">
                      <h3>&nbsp;</h3>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="service-grid text-center"> <a href="CompanyRegi.php"><img src="images/sample/staff-512.png" width="145" height="100" /></a>
                      <h3><a href="CompanyRegi.php">Company</a></h3>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="service-grid text-center"></div>
                  </div>
                  <div class="clearfix"> </div>
                </div>
                <h4>&nbsp;</h4>
            </div>
            
            
            <div class="span3">
                <div class="service-grids">
                  <div class="col-md-3">
                    <div class="service-grid text-center">
                      <h3>&nbsp;</h3>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="service-grid text-center"> <a href="ApplicantRegi.php"><img src="images/sample/icon2.png" width="145" height="100" /></a>
                      <h3><a href="ApplicantRegi.php">Applicant</a></h3>
                    </div>
                  </div>
                  
                  <div class="col-md-3">
                    <div class="service-grid text-center"></div>
                  </div>
                  <div class="clearfix"> </div>
                </div>
                <h4>&nbsp;</h4>
            </div>
      </div>
    <!--/row-fluid-->
</div>
<!--/container-->

</section>
<!--/bottom-->


</div>

</body>
</html>