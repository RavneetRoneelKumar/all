
<!DOCTYPE HTML>
<html>
	<head>
		<title>Doctor Website Template | Home :: w3layouts</title>
         <?php 
	
	// include the file that defines (contains) the username and password
	require_once("../CIN_628 ASSIGNMENT/web/mysqlconn.php");
	
	// connect to your mysql database
	$dbconn = mysql_connect($hostname, $username, $password) or 
		die('Could not connect: ' . mysql_error());
		
	// set the active database as your database. 	
	mysql_select_db($database, $dbconn);
	
	
?>
		<link href="../CIN_628 ASSIGNMENT/web/css/bootstrap.css" rel='stylesheet' type='text/css' />
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <link href="../CIN_628 ASSIGNMENT/web/css/layout.css" rel="stylesheet" type="text/css" />
		<script src="../CIN_628 ASSIGNMENT/web/js/jquery.min.js"></script>
		 <!-- Custom Theme files -->
		<link href="../CIN_628 ASSIGNMENT/web/css/style.css" rel='stylesheet' type='text/css' />
   		 <!-- Custom Theme files -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		 <!---- start-smoth-scrolling---->
		<script type="text/javascript" src="../CIN_628 ASSIGNMENT/web/js/move-top.js"></script>
		<script type="text/javascript" src="../CIN_628 ASSIGNMENT/web/js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
		 <!---- start-smoth-scrolling---->
		<!----webfonts--->
		<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
		<!---//webfonts--->
		<!----start-top-nav-script---->
		<script>
			$(function() {
				var pull 		= $('#pull');
					menu 		= $('nav ul');
					menuHeight	= menu.height();
				$(pull).on('click', function(e) {
					e.preventDefault();
					menu.slideToggle();
				});
				$(window).resize(function(){
	        		var w = $(window).width();
	        		if(w > 320 && menu.is(':hidden')) {
	        			menu.removeAttr('style');
	        		}
	    		});
			});
		</script>
		<!----//End-top-nav-script---->
        
</head>
	<body>
		<!----- start-header---->
	  <div id="home" class="header">
					<div class="top-header">
						<div class="container">
						<div class="logo">
							<a href="../CIN_628 ASSIGNMENT/web/Nurse.html"><img src="../CIN_628 ASSIGNMENT/web/images/clinic1.png" width="405" height="82" title="doctor" /></a>
						</div>
						<!----start-top-nav---->
						 <nav class="top-nav">
							<ul class="top-nav">
								<li><a href="../CIN_628 ASSIGNMENT/web/Nurse.html">Home </a></li>
								<li><a href="../CIN_628 ASSIGNMENT/web/logout.php" >Logout</a></li>
	<li><a href="../CIN_628 ASSIGNMENT/web/patientAddForm.php">patient Add</a></li>
    <li><a href="../CIN_628 ASSIGNMENT/web/patientAddReport.php" >patient Report</a></li>
    <li><a href="../CIN_628 ASSIGNMENT/web/DrugAddForm1.php" >drug add</a></li>
    <li><a href="../CIN_628 ASSIGNMENT/web/DrugAddReport.php" >drug report</a></li>
    <li class="active"><a href="../CIN_628 ASSIGNMENT/web/PrescriptionAdd.php" >prescription add</a></li>
    <li><a href="../CIN_628 ASSIGNMENT/web/prescriptionReport.php" >prescription report</a></li>
    <li><a href="../CIN_628 ASSIGNMENT/web/FullReport.php" >full report</a></li>
			
							<a href="#" id="pull"><img src="../CIN_628 ASSIGNMENT/web/images/menu-icon.png" title="menu" /></a> </ul>
						</nav>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		<!----- //End-header---->
		<!----start-slider-script---->
			<script src="../CIN_628 ASSIGNMENT/web/js/responsiveslides.min.js"></script>
			 <script>
			    // You can also use "$(window).load(function() {"
			    $(function () {
			      // Slideshow 4
			      $("#slider4").responsiveSlides({
			        auto: true,
			        pager: true,
			        nav: true,
			        speed: 500,
			        namespace: "callbacks",
			        before: function () {
			          $('.events').append("<li>before event fired.</li>");
			        },
			        after: function () {
			          $('.events').append("<li>after event fired.</li>");
			        }
			      });
			
			    });
			  </script>
			<!----//End-slider-script---->
			<!-- Slideshow 4 -->
			    <div  id="top" class="callbacks_container">
			    <script language="javascript">
function Validate() {
	presc_num = document.PRESCRIPTIONADDFORM.presc_num.value
	presc_description  = document.PRESCRIPTIONADDFORM.presc_description.value
	presc_date = document.PRESCRIPTIONADDFORM.presc_date.value
	staff_id = document.PRESCRIPTIONADDFORM.staff_id.value
	pat_id = document.PRESCRIPTIONADDFORM.pat_id.value
	
	if (presc_num == "" || presc_description == ""||  presc_date == ""||  staff_id == "" || pat_id == "" )
	{
		Message = "Please enter all required information" + "\n"
		alert(Message)
		return false
	}
	else
	{
		Message = ""
		document.PRESCRIPTIONADDFORM.submit()
		return true
	}
}
  </script>
</head>
<body>


  
  <form method="post" action="../CIN_628 ASSIGNMENT/web/prescAdd.php" name="drug">
   
    <table style="background-color: rgb(245, 245, 245); width: 80%; text-align: left; margin-left: auto; margin-right: auto;" border="0" cellpadding="2" cellspacing="2">

    <tbody>

      <tr style="font-weight: bold; color: rgb(255, 255, 255); font-family: Verdana;" align="center">

        <td height="41" colspan="2" rowspan="1" style="width: 100%; background-color:#6DBEE4;"><big><big>PRESCRIPTION ADD FORM</big></big></td>

      </tr>
      
    <tr>
      <td height="31" style="text-align: left; width: 30%;">Prescription Number:</td>
      <td style="width: 400px;"><input name="presc_num"></td>
    </tr>
    <tr>
      <td height="32" style="text-align: left; width: 30%;">Description:</td>
      <td style="width: 588px; font-family: Verdana;"><input name="presc_description" maxlength="15" size="15" ></td>
    </tr>
      <td height="34" style="text-align: left; width: 30%;"><p>Prescription Date :</p>
        <p>(YYYY/MM/DD)</p></td>
      <td style="width: 400px;"><input name="presc_date" ></td>
    </tr>
        <td height="30" style="text-align: left; width: 30%;">Staff ID:</td>
        <td style="width: 460px;">
      <select size="1" name="staff_id">
<?php 
	// fill staff list box with department names 
	$id = mysql_query("select * from staff") or die('Query failed: ' . mysql_error());
		
	while ($line = mysql_fetch_array($id, MYSQL_ASSOC)) 
	{ 
		echo "<option value='" . $line['staff_id'] . "'>"; 
		echo $line['staff_id'] . "</option>"; 
	} 
?>
        </select>
        </td>
                
      </tr>
        <td style="font-family: Verdana; width: 237px;">Patient ID:</td>
        <td style="width: 460px;">
        <select size="1" name="pat_id">
<?php 
	
	$pat = mysql_query("select * from patient") or die('Query failed: ' . mysql_error());
		
	while ($line = mysql_fetch_array($pat, MYSQL_ASSOC)) 
	{ 
		echo "<option value='" . $line['pat_id'] . "'>"; 
		echo $line['pat_id'] . "</option>"; 
	} 
?>
        </select>
        </td>
                
    <tr align="left">
      <td height="45" colspan="2" style="text-align:center; width: 588px;"><input name="Submit" value="Add" type="submit"><input name="Reset" value="Reset" type="reset"></td>
    </tr>
  </tbody>
</table
><div style="margin-left: 80px;"></div>

<div class="clearfix"> </div>
		   </form>

<?php 
	// close connection to database 
	mysql_close($dbconn);
?>
    </body>
</html>

