<!DOCTYPE html>
 <html class="no-js"> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Home Page | ONLINE JOB APPLICATION</title>
   
   

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">

 
</head>

<body>

    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                 <a id="logo"  href="index.html"><img src="../I.T project/images/online-job-logo-1-f.jpg"  title="online" /></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li ><a href="index.html">Home</a></li>
                        <li><a href="SearchNew.php">Job Search</a></li>
                        <li><a href="PostJobLogin.html">Post Job</a></li>
                        <li><a href="aboutUs.html">About US</a></li>
                       
                               
                                <li><a href="resgisterchoice.php">Register</a></li>
                                <li class="active"><a href="loginchoice.php">Login</a></li>
                  </ul>
                        </li>
                        
                        </li>
                    </ul>        
                </div><!--/.nav-collapse -->
          </div>
        </div>
    </header>
    <!-- /header -->

    <!--Slider-->
    <section id="slide-show">
      <!-- /slider-wrapper -->           
</section>
<!--/Slider-->

<section class="main-info"></section>

<!--Services--><!--/Services-->


<!--Bottom-->
<section id="bottom" class="main">
    <!--Container-->
     <div  id="top" class="callbacks_container">
           <div class="form-bg">
		  <form id="form1" name="form1" method="post" action="checklogin3.php">
          
	<h2 align="center"> Adminstrator Login</h2>
				<p align="center"><input type="text" placeholder="Email"  name="ADMIN_EMAIL" id="ADMIN_EMAIL" />
				</p>
<p align="center"><input type="password" placeholder="Password" name="ADMIN_PASSWORD" id="ADMIN_PASSWORD" />
			</p>
<div align="center">
  <input name="submit" type="submit" value="Login" /> &nbsp;&nbsp;
  <input name="Reset" type="reset" value="clear"/>
 
  
     </div>
</form></div>
<br/> </br>
</form> </div>
                
<!--/container-->

</section>



</body>
</html>